import React from 'react';
import { Book, Code, Shield, FileText, Layout, ArrowRight } from 'lucide-react';

const StaticPageLayout = ({ title, subtitle, icon: Icon, children }: { title: string, subtitle: string, icon: any, children: React.ReactNode }) => (
    <div className="pt-32 pb-24 min-h-screen bg-slate-50 animate-fade-in">
        <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
                <div className="flex flex-col md:flex-row items-center gap-6 mb-12">
                    <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                        <Icon className="w-8 h-8 text-primary" />
                    </div>
                    <div className="text-center md:text-left">
                        <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-3 tracking-tight">
                            {title}
                        </h1>
                        <p className="text-lg text-slate-500 font-medium max-w-2xl">
                            {subtitle}
                        </p>
                    </div>
                </div>

                <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-8 md:p-12 space-y-8">
                        {children}
                    </div>
                </div>
            </div>
        </div>
    </div>
);

export const ApiDocsPage = () => (
    <StaticPageLayout 
        title="API Documentation" 
        subtitle="Integrate LeafGuard AI diagnostics into your own agricultural applications."
        icon={Code}
    >
        <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900">Introduction</h2>
            <p className="text-slate-600 leading-relaxed">
                The LeafGuard API provides developers with access to our advanced plant disease detection models. 
                Our RESTful API allows you to upload leaf images and receive detailed analysis results in JSON format.
            </p>
        </section>

        <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900">Authentication</h2>
            <div className="bg-slate-900 rounded-xl p-6 text-slate-300 font-mono text-sm">
                <p># Request with API Key</p>
                <p>curl -X POST https://api.leafguard.ai/v1/predict \</p>
                <p>  -H "Authorization: Bearer YOUR_API_KEY" \</p>
                <p>  -F "file=@leaf.jpg"</p>
            </div>
        </section>

        <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900">Endpoints</h2>
            <div className="grid gap-4">
                {[
                    { method: 'POST', path: '/v1/predict', desc: 'Predict disease from a leaf image' },
                    { method: 'GET', path: '/v1/diseases', desc: 'Get list of supported diseases' },
                    { method: 'GET', path: '/v1/usage', desc: 'Check your current API usage' },
                ].map((item, i) => (
                    <div key={i} className="flex items-center gap-4 p-4 rounded-xl border border-slate-100 hover:border-primary/20 transition-colors">
                        <span className="px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-md">{item.method}</span>
                        <code className="text-slate-700 font-bold">{item.path}</code>
                        <span className="text-slate-500 text-sm ml-auto">{item.desc}</span>
                    </div>
                ))}
            </div>
        </section>
    </StaticPageLayout>
);

export const PrivacyPage = () => (
    <StaticPageLayout 
        title="Privacy Policy" 
        subtitle="How we handle your data and protect your privacy at LeafGuard."
        icon={Shield}
    >
        <div className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-bold text-slate-900 mb-4">1. Information We Collect</h2>
            <p className="text-slate-600 mb-6">
                We collect images of plant leaves that you upload for analysis. These images are processed by our AI models to provide diagnostics. 
                We also collect basic usage analytics to improve our service.
            </p>

            <h2 className="text-2xl font-bold text-slate-900 mb-4">2. How We Use Your Data</h2>
            <p className="text-slate-600 mb-6">
                The images you upload are used primarily for real-time analysis. We may use anonymized images to further train and improve our disease detection algorithms, helping farmers worldwide.
            </p>

            <h2 className="text-2xl font-bold text-slate-900 mb-4">3. Data Security</h2>
            <p className="text-slate-600 mb-6">
                We implement industry-standard security measures to protect your data. Your uploads are encrypted during transmission and stored securely if you choose to save your results.
            </p>
        </div>
    </StaticPageLayout>
);

export const TermsPage = () => (
    <StaticPageLayout 
        title="Terms of Service" 
        subtitle="The legal agreement between you and LeafGuard AI."
        icon={FileText}
    >
        <div className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-bold text-slate-900 mb-4">1. Acceptance of Terms</h2>
            <p className="text-slate-600 mb-6">
                By accessing or using LeafGuard, you agree to be bound by these Terms of Service and all applicable laws and regulations.
            </p>

            <h2 className="text-2xl font-bold text-slate-900 mb-4">2. Use License</h2>
            <p className="text-slate-600 mb-6">
                Permission is granted to use LeafGuard for personal or commercial agricultural diagnostic purposes. This is the grant of a license, not a transfer of title.
            </p>

            <h2 className="text-2xl font-bold text-slate-900 mb-4">3. Disclaimer</h2>
            <p className="text-slate-600 mb-6">
                LeafGuard AI diagnostics are provided for informational purposes only. While highly accurate, results should be verified with local agricultural experts for critical crop management decisions.
            </p>
        </div>
    </StaticPageLayout>
);

export const BlogPage = () => (
    <StaticPageLayout 
        title="Agricultural Blog" 
        subtitle="Insights on AI, sustainable farming, and plant pathology."
        icon={Layout}
    >
        <div className="grid md:grid-cols-2 gap-8">
            {[
                {
                    title: "The Future of AI in Sustainable Farming",
                    date: "April 20, 2026",
                    excerpt: "How deep learning is helping reduce pesticide use by identifying diseases early.",
                    image: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=400"
                },
                {
                    title: "Common Tomato Blights and How to Spot Them",
                    date: "April 15, 2026",
                    excerpt: "A guide to early detection of late blight and early blight in tomato crops.",
                    image: "https://images.unsplash.com/photo-1592419044706-39796d40f98c?auto=format&fit=crop&q=80&w=400"
                },
                {
                    title: "New Update: 99% Accuracy for Wheat Rust",
                    date: "April 10, 2026",
                    excerpt: "Our latest CNN model update brings significant improvements to cereal crop diagnostics.",
                    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=400"
                }
            ].map((post, i) => (
                <div key={i} className="group cursor-pointer">
                    <div className="aspect-video rounded-2xl overflow-hidden mb-4 border border-slate-100">
                        <img 
                            src={post.image} 
                            alt={post.title} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                    </div>
                    <p className="text-primary text-xs font-bold mb-2 uppercase tracking-wider">{post.date}</p>
                    <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-primary transition-colors">{post.title}</h3>
                    <p className="text-slate-500 text-sm line-clamp-2 mb-4">{post.excerpt}</p>
                    <div className="flex items-center gap-2 text-primary font-bold text-sm">
                        Read More <ArrowRight className="w-4 h-4" />
                    </div>
                </div>
            ))}
        </div>
    </StaticPageLayout>
);
